package com.kingminer7.km7challengebase;

import net.fabricmc.api.ModInitializer;

public class Main implements ModInitializer {

    @Override
    public void onInitialize() {

    }
}
